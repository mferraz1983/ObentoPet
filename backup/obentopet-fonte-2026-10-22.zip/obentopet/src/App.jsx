import { useState } from "react";
import { useAuth } from "./state/Auth.jsx";
import { DataProvider, useData } from "./state/Data.jsx";
import Login from "./views/Login.jsx";
import Hoje from "./views/Hoje.jsx";
import Entregas from "./views/Entregas.jsx";
import Clientes from "./views/Clientes.jsx";
import Produtos from "./views/Produtos.jsx";
import Admin from "./views/Admin.jsx";
import { Modal, Field } from "./components/ui.jsx";
import { db } from "./lib/supabase.js";

function ChangePassword({ onClose }) {
  const [a, setA] = useState(""), [b, setB] = useState(""), [msg, setMsg] = useState(""), [busy, setBusy] = useState(false);
  const save = async () => {
    if (a.length < 10) return setMsg("A senha precisa ter pelo menos 10 caracteres.");
    if (a !== b) return setMsg("As senhas não conferem.");
    setBusy(true);
    const { error } = await db.auth.updateUser({ password: a });
    setBusy(false);
    if (error) return setMsg(error.message);
    setMsg("Senha alterada com sucesso!"); setA(""); setB("");
  };
  return (
    <Modal title="Trocar minha senha" onClose={onClose}>
      <Field label="Nova senha (mín. 10 caracteres)"><input type="password" autoComplete="new-password" value={a} onChange={(e) => setA(e.target.value)} /></Field>
      <Field label="Repita a nova senha"><input type="password" autoComplete="new-password" value={b} onChange={(e) => setB(e.target.value)} /></Field>
      {msg && <div className={msg.includes("sucesso") ? "muted" : "err"}>{msg}</div>}
      <button className="btn" style={{ marginTop: 12 }} disabled={busy} onClick={save}>{busy ? "Salvando…" : "Salvar nova senha"}</button>
    </Modal>
  );
}

const ALL = [["hoje", "Hoje", "🏠"], ["entregas", "Entregas", "🚚"], ["clientes", "Clientes", "🐶"], ["produtos", "Produtos", "📦"], ["admin", "Admin", "⚙️"]];
const ALLOWED = { admin: ["hoje", "entregas", "clientes", "produtos", "admin"], operacional: ["hoje", "entregas", "clientes", "produtos"], portador: ["hoje", "entregas"] };

function Shell() {
  const { role, profile, signOut } = useAuth();
  const D = useData();
  const tabs = ALL.filter(([k]) => ALLOWED[role].includes(k));
  const [view, setView] = useState("hoje");
  const [pw, setPw] = useState(false);
  const View = { hoje: Hoje, entregas: Entregas, clientes: Clientes, produtos: Produtos, admin: Admin }[view];
  return (
    <div className="app">
      <div className="top"><img src={`${import.meta.env.BASE_URL}logo-menu.png?v=1`} alt="ObentōPet" className="top-logo" /><span><small>{profile?.nome} · {role} </small><button className="btn ghost sm" onClick={() => setPw(true)}>Senha</button> <button className="btn ghost sm" onClick={signOut}>Sair</button></span></div>
      <div className="nav"><div>{tabs.map(([k, l, i]) => <button key={k} className={view === k ? "on" : ""} aria-current={view === k ? "page" : undefined} onClick={() => setView(k)}><span className="i">{i}</span>{l}</button>)}</div></div>
      {pw && <ChangePassword onClose={() => setPw(false)} />}
      <div className="main">{!D.ready ? <p className="muted">Carregando…</p> : D.error ? <p className="err">Erro: {D.error}</p> : <View go={setView} />}</div>
    </div>
  );
}

export default function App() {
  const { session, role, loading, signOut } = useAuth();
  if (loading) return <p className="muted" style={{ padding: 24 }}>Carregando…</p>;
  if (!session) return <Login />;
  if (!role) return (
    <div className="login"><h3>Acesso pendente</h3><p className="muted">Sua conta ainda não tem perfil. Peça a um administrador para liberar o acesso.</p>
      <button className="btn ghost" onClick={signOut}>Sair</button></div>);
  return <DataProvider><Shell /></DataProvider>;
}
