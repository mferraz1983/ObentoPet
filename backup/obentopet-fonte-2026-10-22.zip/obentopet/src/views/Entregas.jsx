import { useMemo, useState } from "react";
import { useData } from "../state/Data.jsx";
import { useAuth } from "../state/Auth.jsx";
import { todayISO, addDays, formatDateFull, formatDateBR, dowShort } from "../lib/dates.js";
import { getDeliveriesForRange, CANCELLED } from "../lib/schedule.js";
import { groupStops, buildRoteiroText, buildRoteiroHTML, printHtmlDoc } from "../lib/roteiro.js";
import { Modal, Field, copyText } from "../components/ui.jsx";
import { labelPagesHTML, loadLabelStore, activeLabelSettings } from "../lib/labels.js";

export default function Entregas() {
  const D = useData();
  const { isStaff } = useAuth();
  const [mode, setMode] = useState("hoje");
  const [from, setFrom] = useState(todayISO()), [to, setTo] = useState(addDays(todayISO(), 6));
  const [resch, setResch] = useState(null), [newDate, setNewDate] = useState(""), [q, setQ] = useState("");
  const today = todayISO();
  const [d1, d2] = mode === "hoje" ? [today, today] : mode === "amanha" ? [addDays(today, 1), addDays(today, 1)] : [from <= to ? from : to, from <= to ? to : from];
  const items = useMemo(() => getDeliveriesForRange(D.plans, D.reschedules, D.avulsaOrders, d1, d2), [D, d1, d2]);
  const ql = q.trim().toLowerCase();
  const sections = useMemo(() => {
    const dates = [...new Set(items.map((i) => i.date))].sort();
    if (mode !== "periodo" && !dates.length) dates.push(d1);
    return dates.map((date) => { const its = items.filter((i) => i.date === date); return { date, items: its, stops: groupStops(its) }; });
  }, [items, mode, d1]);
  const totalStops = sections.reduce((n, x) => n + x.stops.length, 0);
  const statusFor = (s) => (s.pets.every((p) => D.statusOf(p.clientId, p.date) === "entregue") ? "entregue" : "pendente");
  const toggle = (s) => { const next = statusFor(s) === "entregue" ? "pendente" : "entregue"; s.pets.forEach((p) => {
    D.setStatus(p.clientId, p.date, next);
    const plan = D.plans.find((x) => x.id === p.clientId);
    if (plan && plan.frequency !== "avulsa" && plan.units) D.adjust("sub", p.clientId, next === "entregue" ? -plan.units : plan.units);
  }); };
  const moveStop = async (following) => {
    const { stop, date } = resch;
    for (const p of stop.pets) {
      await D.reschedule(p.clientId, date, newDate);
      if (following) { const row = D.clients.find((c) => c.id === p.clientId); if (row && row.frequency !== "avulsa") await D.save("clients", { ...row, next_date: newDate }); }
    }
    await D.reload(); setResch(null);
    D.say(following ? "Reagendado: esta e as próximas entregas" : "Reagendado: só esta entrega");
  };
  const copyAll = () => copyText(sections.filter((x) => x.items.length).map((x) => buildRoteiroText(x.date, x.items, { statusOf: D.statusOf })).join("\n\n"), D.say);
  const printLabels = () => {
    const list = items.filter((it) => !ql || ((it.client.dog || "") + " " + (it.client.tutor || "") + " " + (it.client.address || "") + " " + (it.client.bairro || "")).toLowerCase().includes(ql));
    if (!list.length) return D.say("Nenhuma entrega para imprimir etiquetas");
    printHtmlDoc(labelPagesHTML(list.map((it) => ({ client: it.client, date: it.date })), activeLabelSettings(loadLabelStore())).html, { waitFonts: true });
  };
  const printAll = () => {
    const docs = sections.filter((x) => x.items.length).map((x) => buildRoteiroHTML(x.date, x.items));
    if (docs.length === 1) return printHtmlDoc(docs[0]);
    const body = (h) => h.match(/<body>([\s\S]*)<\/body>/)[1];
    printHtmlDoc(docs[0].replace(/<body>[\s\S]*<\/body>/, "<body>" + docs.map((h) => '<div style="page-break-after:always">' + body(h) + "</div>").join("") + "</body>"));
  };
  const renderStop = (s, i, date) => { const ok = statusFor(s) === "entregue"; return (
      <div key={s.key} className="card" style={ok ? { opacity: .6 } : null}>
        <div className="row"><b className="grow">{i + 1}. {s.pets.map((p) => p.dog).join(" & ")}</b>
          <button className={"btn sm " + (ok ? "ghost" : "ok")} onClick={() => toggle(s)}>{ok ? "✓ Entregue" : "Marcar entregue"}</button></div>
        <div className="muted">{s.tutor}</div>
        {isStaff && (() => { const sh = s.pets.map((p) => D.petByClient[p.clientId]).filter((x) => x && x.tutor2_id); if (!sh.length) return null; const pet = sh[0], a = D.tutorsById[pet.tutor_id], b = D.tutorsById[pet.tutor2_id]; if (!a || !b) return null;
          return <div className="row" style={{ margin: "6px 0" }}><span className="muted">Guarda compartilhada · entregar em:</span>
            <select value={pet.entrega_com || "principal"} onChange={async (e) => { for (const x of sh) await D.save("pets", { ...x, entrega_com: e.target.value }); await D.reload(); }}>
              <option value="principal">{a.nome.split(" ")[0]}</option><option value="segundo">{b.nome.split(" ")[0]}</option></select></div>; })()}
        <div>📍 {s.address}{s.bairro ? " - " + s.bairro : ""}</div>
        {s.complemento && <div className="muted">🏢 {s.complemento}</div>}
        {s.referencia && <div className="muted">🧭 {s.referencia}</div>}
        {s.janelaEntrega && <div className="muted">🕒 {s.janelaEntrega}</div>}
        {(s.volumes || s.units) ? <div className="muted">📦 {s.volumes ? s.volumes + " vol." : ""} {s.units ? s.units + " un." : ""}</div> : null}
        {s.notes && <div className="muted">📝 {s.notes}</div>}
        <div className="row" style={{ marginTop: 8 }}>
          {s.address && <a className="btn ghost sm" target="_blank" rel="noreferrer" href={"https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(s.address + " " + (s.bairro || "") + " São Paulo")}>Mapa</a>}
          {s.phone && <a className="btn ghost sm" href={"tel:" + s.phone.replace(/\D/g, "")}>Ligar</a>}
          {isStaff && <button className="btn ghost sm" onClick={() => { setResch({ stop: s, date }); setNewDate(addDays(date, 1)); }}>Reagendar</button>}
        </div>
      </div>); };
  return (<>
    <div className="sticky-top">
    <input placeholder="Buscar pet, tutor ou endereço…" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
    <div className="tabs">{[["hoje", "HOJE · " + formatDateBR(today)], ["amanha", "AMANHÃ · " + formatDateBR(addDays(today, 1))], ["periodo", "SELECIONAR PERÍODO"]].map(([k, l]) => <button key={k} className={k === mode ? "on" : ""} onClick={() => setMode(k)}>{l}</button>)}</div>
    </div>
    <div className="row" style={{ marginBottom: 12, flexWrap: "wrap" }}>
      {mode === "periodo" && <><label className="muted">De <input type="date" value={from} onChange={(e) => e.target.value && setFrom(e.target.value)} style={{ width: 150 }} /></label>
        <label className="muted">até <input type="date" value={to} onChange={(e) => e.target.value && setTo(e.target.value)} style={{ width: 150 }} /></label></>}
      <span className="grow" />
      <button className="btn ghost sm" disabled={!items.length} onClick={copyAll}>Copiar p/ WhatsApp</button>
      <button className="btn ghost sm" disabled={!items.length} onClick={printLabels}>🏷️ Etiquetas</button>
      <button className="btn sm" disabled={!items.length} onClick={printAll}>PDF / Imprimir</button>
    </div>
    <div className="muted" style={{ marginBottom: 8 }}>{mode === "periodo" ? formatDateBR(d1) + " a " + formatDateBR(d2) : formatDateFull(d1)} · {totalStops} parada(s) · {items.length} pet(s)</div>
    {!items.length && <div className="card muted">Sem entregas {mode === "periodo" ? "neste período" : "neste dia"}.</div>}
    {sections.map((sec) => { const shown = sec.stops.map((st, i) => ({ st, i })).filter(({ st }) => !ql || (st.pets.map((p) => p.dog).join(" ") + " " + st.tutor + " " + (st.address || "") + " " + (st.bairro || "")).toLowerCase().includes(ql));
      return (<div key={sec.date}>
        {mode === "periodo" && sec.stops.length > 0 && <h3 style={{ margin: "14px 0 6px" }}>{formatDateFull(sec.date)} <span className="muted" style={{ fontWeight: 400 }}>· {sec.stops.length} parada(s)</span></h3>}
        {!!sec.stops.length && !shown.length && <div className="card muted">Nenhuma parada encontrada para "{q}".</div>}
        {shown.map(({ st, i }) => renderStop(st, i, sec.date))}
      </div>); })}
    {resch && <Modal title="Reagendar entrega" onClose={() => setResch(null)}>
      <div className="muted" style={{ marginBottom: 6 }}>{resch.stop.pets.map((p) => p.dog).join(" & ")} · de {formatDateBR(resch.date)}</div>
      <Field label="Nova data"><input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} /></Field>
      {newDate && newDate !== resch.date && <div className="card" style={{ marginTop: 12 }}>
        <b>Reagendar para {formatDateBR(newDate)}:</b>
        <div className="muted" style={{ margin: "4px 0 10px" }}>Quer mudar só esta entrega ou também as seguintes (mantendo a frequência de cada cliente a partir da nova data)?</div>
        <div className="row" style={{ flexWrap: "wrap" }}>
          <button className="btn" onClick={() => moveStop(false)}>APENAS ESTA ENTREGA</button>
          <button className="btn ghost" onClick={() => moveStop(true)}>ESTA E TODAS AS SEGUINTES</button>
        </div></div>}
      <div className="row" style={{ marginTop: 12 }}>
        <button className="btn bad" onClick={async () => { for (const p of resch.stop.pets) await D.reschedule(p.clientId, resch.date, CANCELLED); await D.reload(); setResch(null); }}>Cancelar esta entrega</button>
      </div></Modal>}
  </>);
}
