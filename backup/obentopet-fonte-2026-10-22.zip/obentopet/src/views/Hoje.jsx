import { useMemo } from "react";
import { useData } from "../state/Data.jsx";
import { todayISO, addDays, formatDateFull, formatDateBR } from "../lib/dates.js";
import { getDeliveriesForRange } from "../lib/schedule.js";
import { groupStops } from "../lib/roteiro.js";
import { upcomingBirthdays, ageLabel } from "../lib/birthdays.js";

export const PENDING_WINDOW_DAYS = 14;
export const PENDING_START = "2026-10-21"; // pendências contadas a partir desta data

export default function Hoje({ go }) {
  const D = useData();
  const today = todayISO();
  const { todayItems, late, bdays } = useMemo(() => {
    const w = addDays(today, -PENDING_WINDOW_DAYS), lateStart = w > PENDING_START ? w : PENDING_START;
    const all = getDeliveriesForRange(D.plans, D.reschedules, D.avulsaOrders, lateStart, today);
    return {
      todayItems: all.filter((i) => i.date === today),
      late: all.filter((i) => i.date < today && D.statusOf(i.client.id, i.date) !== "entregue"),
      bdays: upcomingBirthdays(D.pets, today, 0),
    };
  }, [D, today]);
  const lowSnack = D.snack.filter((x) => (x.min_stock || 0) > 0 && x.balance <= x.min_stock);
  const done = todayItems.filter((i) => D.statusOf(i.client.id, i.date) === "entregue").length;
  const stops = groupStops(todayItems);
  return (<>
    <h2 style={{ margin: "0 0 12px" }}>{formatDateFull(today)}</h2>
    <div className="card">
      <h3>🎂 Aniversariantes de hoje</h3>
      {!bdays.length ? <span className="muted">Nenhum pet faz aniversário hoje.</span> :
        bdays.map((b) => <div key={b.pet.id} className="stop"><b>{b.pet.nome}</b> {ageLabel(b.pet.nascimento, b.date) ? "faz " + ageLabel(b.pet.nascimento, b.date) : "faz aniversário hoje"} <div className="muted">{D.tutorsById[b.pet.tutor_id]?.nome}</div></div>)}
    </div>
    {lowSnack.length > 0 && <div className="card" style={{ borderColor: "var(--bad)" }}><h3 style={{ color: "var(--bad)" }}>⚠ Petiscos acabando</h3>
      {lowSnack.map((x) => <div key={x.id} className="stop"><b>{x.name}</b> <span style={{ color: "var(--bad)" }}>{x.balance <= 0 ? "zerado" : "saldo " + x.balance}</span><span className="muted"> · mín. {x.min_stock}</span></div>)}
      <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={() => go("produtos")}>Ver estoque</button></div>}
    <div className="card">
      <h3>📦 Entregas de hoje</h3>
      <div className="row">{!todayItems.length ? <span className="muted">Sem entregas hoje.</span> : done === todayItems.length ? <><span className="big" style={{ color: "var(--ok)" }}>✓ OK</span><span className="muted">todas entregues · {stops.length} parada(s)</span></> : <><span className="big" style={{ color: "var(--warn)" }}>{todayItems.length - done}</span><span className="muted">{todayItems.length - done === 1 ? "entrega pendente" : "entregas pendentes"} · {stops.length} parada(s)</span></>}</div>
      {stops.slice(0, 4).map((s) => <div key={s.key} className="stop"><b>{s.pets.map((p) => p.dog).join(" & ")}</b><div className="muted">{s.bairro || s.address}</div></div>)}
      <button className="btn" style={{ marginTop: 8 }} onClick={() => go("entregas")}>Abrir roteiro</button>
    </div>
    <div className="card">
      <h3>⏳ Entregas pendentes</h3>
      {!late.length ? <span className="muted">Nenhuma entrega atrasada.</span> :
        late.map((i) => <div key={i.client.id + i.date} className="stop"><b>{i.client.dog}</b> · {i.client.tutor}<div className="muted">era para {formatDateBR(i.date)}</div></div>)}
    </div>
  </>);
}
