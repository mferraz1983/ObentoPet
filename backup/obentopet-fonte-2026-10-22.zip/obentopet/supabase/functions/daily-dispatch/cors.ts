// Habilita CORS (o navegador chama a função direto) envolvendo Deno.serve.
const orig = Deno.serve.bind(Deno);
const H: Record<string, string> = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "access-control-allow-methods": "POST, OPTIONS",
};
// deno-lint-ignore no-explicit-any
(Deno as any).serve = (h: (r: Request) => Response | Promise<Response>) =>
  orig(async (req: Request) => {
    if (req.method === "OPTIONS") return new Response("ok", { headers: H });
    const r = await h(req);
    const hd = new Headers(r.headers);
    for (const k in H) hd.set(k, H[k]);
    return new Response(r.body, { status: r.status, headers: hd });
  });
